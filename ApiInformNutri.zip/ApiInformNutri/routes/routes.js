const connection = require('../database/connection')
const express = require('express')
const router = express.Router()
const serviceController = require('../controllers/serviceController')

router.get('/servicos', serviceController.listarServicos)

router.get('/servicos/:ID_SERVICE', serviceController.listarUmServico)

router.get('/servicos/dados/:ID_SERVICE', serviceController.listarDadosServicos)

router.get('/servicos/dadosProdutos/:ID_PRODUCT', serviceController.listarProdutos)

module.exports = router
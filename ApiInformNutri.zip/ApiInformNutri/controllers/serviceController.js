const database = require('../database/connection')

class serviceController{
    listarServicos (request, response){
        database.select("*").table("SERVICES").where({"IS_VALID" : 'S'}).then(servicos=>{
            console.log(servicos)
            response.json(servicos)
        }).catch(error => {
            console.log(error)
        })
    }

    listarUmServico (request, response){
        const ID_SERVICE = request.params

        database.select("*").table("SERVICES").where(ID_SERVICE, ID_SERVICE).then(servicos=>{
            console.log(servicos)
            response.json(servicos)
        }).catch(error => {
            console.log(error)
        })
    }

    listarDadosServicos (request, response){
        const ID_SERVICE = request.params
        database.select(["SERVICES.NAME_SERVICE", "SERVICES_PRODUCTS.*"]).table("SERVICES_PRODUCTS").innerJoin("SERVICES", "SERVICES.ID_SERVICE", "SERVICES_PRODUCTS.ID_SERVICE_PROD").where("SERVICES_PRODUCTS.ID_SERVICE_PROD" , ID_SERVICE ).then(servicos=>{
            console.log(servicos)
            response.json(servicos)
        }).catch(error => {
            console.log(error)
        })
    }

    listarProdutos (request, response){
        const ID_PRODUCT = request.params

        database.select(["*"]).table("SERVICES_PRODUCTS").where(ID_PRODUCT).then(servicos=>{
            console.log(servicos)
            response.json(servicos)
        }).catch(error => {
            console.log(error)
        })
    }
}

module.exports = new serviceController()